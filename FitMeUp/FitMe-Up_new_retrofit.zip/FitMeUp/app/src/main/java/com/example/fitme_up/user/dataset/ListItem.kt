package com.example.fitme_up.user.dataset

data class ListItem(val type: Int, val data: Any)
