package com.example.fitme_up.register

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.fitme_up.R
import com.example.fitme_up.ViewModelSelectDay


class RegisterCoachFragment3 : Fragment() {

//    private var checkboxListener: OnCheckboxSelectedListener? = null

    private lateinit var registerBtn: Button
//    private lateinit var sharedViewModel: ViewModelSelectSport
    private lateinit var sharedViewModel2: ViewModelSelectDay

    private lateinit var checkMonday: CheckBox
    private lateinit var checkTuesday: CheckBox
    private lateinit var checkWednesday: CheckBox
    private lateinit var checkThursday: CheckBox
    private lateinit var checkFriday: CheckBox
    private lateinit var checkSaturday: CheckBox
    private lateinit var checkSunday: CheckBox

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_register_coach3, container, false)

        registerBtn = view.findViewById(R.id.registerButtonCoach3)

        checkMonday = view.findViewById(R.id.checkbox_monday)
        checkTuesday = view.findViewById(R.id.checkbox_tuesday)
        checkWednesday = view.findViewById(R.id.checkbox_wednesday)
        checkThursday = view.findViewById(R.id.checkbox_thursday)
        checkFriday = view.findViewById(R.id.checkbox_friday)
        checkSaturday = view.findViewById(R.id.checkbox_saturday)
        checkSunday = view.findViewById(R.id.checkbox_sunday)

//        sharedViewModel = ViewModelProvider(requireActivity()).get(ViewModelSelectSport::class.java)
        sharedViewModel2 = ViewModelProvider(requireActivity()).get(ViewModelSelectDay::class.java)

//        sharedViewModel.selectedState.observe(viewLifecycleOwner, Observer { selected ->
//            if (selected != null) {
//                //ini buat get sport di page sebelumnya
//                when (selected) {
//                    "Badminton" -> {
//                        Toast.makeText(requireContext(), "Selected state: $selected", Toast.LENGTH_SHORT).show()
//                    }
//                    "Futsal" -> {
//                        Toast.makeText(requireContext(), "Selected state: $selected", Toast.LENGTH_SHORT).show()
//                    }
//                }
//            }
//        })

        return view
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

//        sharedViewModel.updateSelectedState(null)
        sharedViewModel2.clearSelectedDays()

        checkMonday.setOnCheckedChangeListener { _, isChecked ->
            updateSelectedDaysList("Monday", isChecked)
        }
        checkTuesday.setOnCheckedChangeListener { _, isChecked ->
            updateSelectedDaysList("Tuesday", isChecked)
        }
        checkWednesday.setOnCheckedChangeListener { _, isChecked ->
            updateSelectedDaysList("Wednesday", isChecked)
        }
        checkThursday.setOnCheckedChangeListener { _, isChecked ->
            updateSelectedDaysList("Thursday", isChecked)
        }
        checkFriday.setOnCheckedChangeListener { _, isChecked ->
            updateSelectedDaysList("Friday", isChecked)
        }
        checkSaturday.setOnCheckedChangeListener { _, isChecked ->
            updateSelectedDaysList("Saturday", isChecked)
        }
        checkSunday.setOnCheckedChangeListener { _, isChecked ->
            updateSelectedDaysList("Sunday", isChecked)
        }

        registerBtn.setOnClickListener() {

            if(checkMonday.isChecked || checkTuesday.isChecked || checkWednesday.isChecked ||
                checkThursday.isChecked || checkFriday.isChecked || checkSaturday.isChecked || checkSunday.isChecked){
                val frag = RegisterCoachFragment4()
                val tran = fragmentManager?.beginTransaction()
                tran?.replace(R.id.frame_register_cont, frag)?.commit()
                tran?.addToBackStack(null)
            }
            else{
                Toast.makeText(activity, "Please select schedule", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun updateSelectedDaysList(day: String, isChecked: Boolean) {
        if (isChecked) {
            // Add the checked day to the list
            sharedViewModel2.addSelectedDay(day)
        } else {
            // Remove the unchecked day from the list
            sharedViewModel2.removeSelectedDay(day)
        }
    }
}
