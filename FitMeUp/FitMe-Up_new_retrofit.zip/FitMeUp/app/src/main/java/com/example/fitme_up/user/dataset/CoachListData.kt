package com.example.fitme_up.user.dataset

data class CoachListData(val Name: String, val Sport: String, val Domicile: String, val Phone: String)
