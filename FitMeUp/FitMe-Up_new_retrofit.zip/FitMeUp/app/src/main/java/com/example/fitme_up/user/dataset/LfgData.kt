package com.example.fitme_up.user.dataset

data class LfgData(val lfgName: String, val lfgSport: String, val lfgDomicile: String, val lfgTime: String)
