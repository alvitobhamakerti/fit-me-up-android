package com.example.fitme_up.viewmodel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.fitme_up.Repo
import com.example.fitme_up.blueprint.DataPost
import com.example.fitme_up.blueprint.Domicile
import com.example.fitme_up.blueprint.FavSportData
import com.example.fitme_up.blueprint.MainData
import kotlinx.coroutines.launch
import retrofit2.Response

class ViewModelSportList(private val repo: Repo) : ViewModel() {

    var sportList: MutableLiveData<Response<List<DataPost>>> = MutableLiveData()
//    var domicileList: MutableLiveData<Response<Domicile>> = MutableLiveData()
    var domicileList: MutableLiveData<Response<MainData>> = MutableLiveData()// -> kl mau ganti
        //    val selectedState: MutableLiveData<String?>
//        get() = _selectedState

    fun getPost() {
        viewModelScope.launch {
            val response = repo.getPost()
            sportList.value = response
        }
    }

//    fun getPost2() {
//        viewModelScope.launch {
//            val response = repo.getDomicilePost()
//            domicileList.value = response
//
//        }
//    }
    fun getPost2() {
        viewModelScope.launch {
            val response = repo.getDomicilePost()
            domicileList.value = response

        }
    }
}

//package com.example.fitme_up
//
//import androidx.lifecycle.MutableLiveData
//import androidx.lifecycle.ViewModel
//
//class ViewModelSportList : ViewModel() {
//
//    private val _selectedState = MutableLiveData<String?>()
//    val selectedState: MutableLiveData<String?>
//        get() = _selectedState
//
//    fun updateSelectedState(selected: String?) {
//        _selectedState.value = selected
//    }
//}