package com.example.fitme_up

import com.example.fitme_up.blueprint.DataPost
import com.example.fitme_up.blueprint.Domicile
import com.example.fitme_up.blueprint.FavSportData
import com.example.fitme_up.blueprint.MainData
import retrofit2.Response

class Repo {

    suspend fun getPost(): Response<List<DataPost>> {
        return RetrofitClient.instance.getFavSport()
    }

//    suspend fun getDomicilePost(): Response<Domicile> {
//        return RetrofitClient.instance.getDomicile()
//    }

    suspend fun getDomicilePost(): Response<MainData> {
        return RetrofitClient.instance.getDomicile()
    }
}