package com.example.fitme_up.user.dataset

data class SettingsWithdrawData(val withdrawId: String, val withdrawDate: String, val withdrawAmount: Int)
