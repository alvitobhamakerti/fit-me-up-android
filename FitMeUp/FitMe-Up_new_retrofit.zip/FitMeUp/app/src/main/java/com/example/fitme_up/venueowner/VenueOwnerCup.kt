package com.example.fitme_up.venueowner

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import com.example.fitme_up.R

class VenueOwnerCup : Fragment() {

    private lateinit var createCupBtn: Button

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_venue_owner_cup, container, false)

        createCupBtn = view.findViewById(R.id.btn_venue_cup_create_new)

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        createCupBtn.setOnClickListener(){
            val frag = VenueOwnerCupCreateNew()
            val tran = fragmentManager?.beginTransaction()
            tran?.addToBackStack(null)
            parentFragmentManager.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE)
            tran?.replace(R.id.fragment_cont, frag)?.commit()
        }
    }

}