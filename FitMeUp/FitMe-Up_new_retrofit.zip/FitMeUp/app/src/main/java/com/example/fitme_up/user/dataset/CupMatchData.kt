package com.example.fitme_up.user.dataset

data class CupMatchData(val team1Name: String, val team1Score: Int, val team2Name: String, val team2Score: Int)
