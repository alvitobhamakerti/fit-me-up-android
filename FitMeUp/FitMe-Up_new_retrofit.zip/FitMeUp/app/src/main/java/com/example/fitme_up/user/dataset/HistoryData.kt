package com.example.fitme_up.user.dataset

data class HistoryData(val VenueName: String, val Sport: String, val CoachName: String, val Domicile: String, val BookDate: String)
