package com.example.fitme_up.user.dataset

data class ActivityData(val img: String, val title: String, val description: String)


