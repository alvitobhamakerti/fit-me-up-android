package com.example.fitme_up.user.dataset

data class VenueImageData(val url: Int)
