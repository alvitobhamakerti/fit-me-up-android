package com.example.fitme_up.blueprint

data class FavSportData(
    val id: Int,
    val title: String,
    val sport_icon: String,
    val created_at: String,
    val updated_at: String
)