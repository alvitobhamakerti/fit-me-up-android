package com.example.fitme_up.register

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ImageButton
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.fitme_up.R
import com.example.fitme_up.ViewModelSelectSport


class RegisterUserFragment2 : Fragment() {

    lateinit var selectSportBtn: Button
    private lateinit var badmintonBtn: ImageButton
    private lateinit var futsalBtn: ImageButton
    private lateinit var badmintonText: TextView
    private lateinit var futsalText: TextView
    private lateinit var sharedViewModel: ViewModelSelectSport
    private lateinit var domicileSpinner: Spinner

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_register_user2, container, false)

        selectSportBtn = view.findViewById(R.id.btn_register_user_select_sport)
        badmintonBtn = view.findViewById(R.id.btn_select_badminton)
        badmintonText = view.findViewById(R.id.text_select_badminton)
        futsalBtn = view.findViewById(R.id.btn_select_futsal)
        futsalText = view.findViewById(R.id.text_select_futsal)
        domicileSpinner = view.findViewById(R.id.spinner_user_register_domicile)

        sharedViewModel = ViewModelProvider(requireActivity()).get(ViewModelSelectSport::class.java)

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        sharedViewModel.updateSelectedState(null)

        badmintonBtn.setBackgroundResource(R.drawable.button_toggle_selector)
        futsalBtn.setBackgroundResource(R.drawable.button_toggle_selector)

        context?.let { it1 -> badmintonText.setTextColor(it1.getColor(R.color.birutua)) }
        context?.let { it1 -> futsalText.setTextColor(it1.getColor(R.color.birutua)) }

        badmintonBtn.setOnClickListener {
            badmintonBtn.isSelected = !badmintonBtn.isSelected
            if (badmintonBtn.isSelected) {
                context?.let { it1 -> badmintonText.setTextColor(it1.getColor(R.color.white)) }
                sharedViewModel.updateSelectedState("Badminton")
            } else {
                context?.let { it1 -> badmintonText.setTextColor(it1.getColor(R.color.birutua)) }
                sharedViewModel.updateSelectedState(null)
            }
        }

        futsalBtn.setOnClickListener() {
            futsalBtn.isSelected = !futsalBtn.isSelected
            if (futsalBtn.isSelected) {
                context?.let { it1 -> futsalText.setTextColor(it1.getColor(R.color.white)) }
                sharedViewModel.updateSelectedState("Futsal")
            } else {
                context?.let { it1 -> futsalText.setTextColor(it1.getColor(R.color.birutua)) }
                sharedViewModel.updateSelectedState(null)
            }
        }

        val domicile_list = resources.getStringArray(R.array.domicile_list)
        if (domicileSpinner != null) {
            val adapter = ArrayAdapter(
                requireContext(),
                android.R.layout.simple_spinner_item, domicile_list
            )
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            domicileSpinner.adapter = adapter
        }

        val alertDialog = getActivity()?.let {

            AlertDialog.Builder(it)
                .setTitle("Confirm Registration")
                .setMessage("Are you sure you want to register?")
                .setPositiveButton("Yes") { _, _ ->
                    val frag = RegisterUserFragment3()
                    val tran = fragmentManager?.beginTransaction()
                    tran?.replace(R.id.frame_register_cont, frag)?.commit()
                    tran?.addToBackStack(null)
                }
                .setNegativeButton("Cancel") { _, _ -> }
                .create()
        }

        selectSportBtn.setOnClickListener() {
            if (badmintonBtn.isSelected || futsalBtn.isSelected) {
                if (badmintonBtn.isSelected && futsalBtn.isSelected) {
                    sharedViewModel.updateSelectedState("Both")
                }
                if (alertDialog != null) {
                    showAlertDialog(alertDialog)
                }
            }
        }
    }

    private fun showAlertDialog(alertDialog: AlertDialog) {
        if (!alertDialog.isShowing) {
            alertDialog.show()
        }
    }
}