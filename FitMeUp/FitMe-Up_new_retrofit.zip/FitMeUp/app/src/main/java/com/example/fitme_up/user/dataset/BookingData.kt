package com.example.fitme_up.user.dataset

data class BookingData(val VenueName: String, val Sport: String, val CoachName: String, val Domicile: String, val BookDate: String)
