package com.example.fitme_up

interface OnItemClickListener {
    fun onItemClick(position: Int)
}