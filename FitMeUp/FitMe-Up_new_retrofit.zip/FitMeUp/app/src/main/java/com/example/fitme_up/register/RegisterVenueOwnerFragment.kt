package com.example.fitme_up.register

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.Fragment
import com.example.fitme_up.R

class RegisterVenueOwnerFragment : Fragment() {

    lateinit var registerButton: Button

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_register_venue_owner, container, false)

        registerButton = view.findViewById(R.id.btn_register_venue_owner)

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        registerButton.setOnClickListener {
            val userFrag = RegisterVenueOwnerFragment2()
            val tran = fragmentManager?.beginTransaction()
            tran?.replace(R.id.frame_register_cont, userFrag)?.commit()
            tran?.addToBackStack(null)
        }

    }

}