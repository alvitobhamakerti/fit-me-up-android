package com.example.fitme_up.coach

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.fitme_up.R
import com.example.fitme_up.coach.adapter.CoachHistoryAdapter
import com.example.fitme_up.coach.dataset.CoachingData

class CoachRequestHistory : Fragment() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var viewAdapter: RecyclerView.Adapter<*>
    private lateinit var viewManager: RecyclerView.LayoutManager

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_coach_request_history, container, false)

        recyclerView = view.findViewById(R.id.recycler_coach_coaching_history)

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewManager = LinearLayoutManager(context)
        recyclerView.layoutManager = viewManager

        val dataList2 = listOf(
            CoachingData("Venue 1", "Jakarta Selatan", "Badminton", "12 December 2023", 1),
            CoachingData("Venue 2", "Jakarta Selatan", "Badminton", "11 December 2023", 2),
            CoachingData("Venue 3", "Jakarta Selatan", "Badminton", "7 December 2023", 1),
            CoachingData("Venue 4", "Jakarta Selatan", "Badminton", "5 December 2023", 1),
            CoachingData("Venue 5", "Jakarta Pusat", "Futsal", "3 December 2023", 1),
            CoachingData("Venue 6", "Jakarta Barat", "Futsal", "1 December 2023", 1),
            CoachingData("Venue 7", "Jakarta Pusat", "Futsal", "29 November 2023", 3),
            CoachingData("Venue 8", "Jakarta Timur", "Futsal", "24 November 2023", 2)
        )
        viewAdapter = CoachHistoryAdapter(dataList2, this)
        recyclerView.adapter = viewAdapter

        addFragmentWithTag(this, "coach_history")

    }

    fun addFragmentWithTag(fragment: Fragment, tag: String) {
        activity?.supportFragmentManager?.beginTransaction()
            ?.replace(R.id.fragment_cont, fragment, tag)
            ?.commit()
    }

}