package com.example.fitme_up.user.dataset

data class CupData(val cupName: String, val cupSport: String, val cupDomicile: String, val cupTime: String)
