package com.example.fitme_up.user.booking

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.fitme_up.OnButtonClickListener
import com.example.fitme_up.R
import com.example.fitme_up.user.adapter.bookingHistoryAdapter.BookingHistoryTab1Adapter
import com.example.fitme_up.user.dataset.BookingData

class BookingHistory_Tab1Fragment : Fragment(), OnButtonClickListener {

    private lateinit var viewAdapter: RecyclerView.Adapter<*>
    private lateinit var viewManager: RecyclerView.LayoutManager
    private lateinit var recyclerView: RecyclerView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_booking_history_tab1, container, false)

        recyclerView = view.findViewById(R.id.historyRecycleListTab1)

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewManager = LinearLayoutManager(context)
        recyclerView.layoutManager = viewManager

        val dataList = listOf(
            BookingData("Venue 1", "Badminton", "Coach 1", "Jakarta Selatan", "28 December 2023"),
            BookingData("Venue 2", "Badminton", "", "Jakarta Pusat", "29 December 2023"),
            BookingData("Venue 3", "Futsal", "Coach 3", "Jakarta Utara", "30 December 2023")
        )

        viewAdapter = BookingHistoryTab1Adapter(dataList, this)

        recyclerView.adapter = viewAdapter
    }

    override fun onButtonClick() {
        val frag = BookingHistoryActiveDetails()
        val tran = fragmentManager?.beginTransaction()
        tran?.replace(R.id.fragment_cont, frag)?.commit()
        tran?.addToBackStack(null)
    }
}

