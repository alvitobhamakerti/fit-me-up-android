package com.example.fitme_up.user.dataset

data class CupTeamData(val teamName: String, val teamSport: String, val teamDomicile: String, val teamMember: Int)
