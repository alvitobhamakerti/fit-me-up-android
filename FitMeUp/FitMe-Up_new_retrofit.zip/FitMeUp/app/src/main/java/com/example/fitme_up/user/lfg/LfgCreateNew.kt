package com.example.fitme_up.user.lfg

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.fitme_up.R
import com.example.fitme_up.Repo
import com.example.fitme_up.RetrofitClient
import com.example.fitme_up.ViewModelSelectSport
import com.example.fitme_up.adapter.SportListAdapter
import com.example.fitme_up.blueprint.FavSportData
import com.example.fitme_up.user.adapter.settingsAdapter.SettingsAdapter
import com.example.fitme_up.viewmodel.ViewModelFactory
import com.example.fitme_up.viewmodel.ViewModelSportList
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class LfgCreateNew : Fragment() {

    private lateinit var btnCreateLfg: Button
    private lateinit var domicileSpinner: Spinner
    private lateinit var sportSpinner: Spinner
    private lateinit var minPlayerInput: EditText

    private val list = ArrayList<FavSportData>()
//    val sportAdapter by lazy { SportListAdapter(requireContext()) }

    //retrofit
    private lateinit var viewModel: ViewModelSportList

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_lfg_create_new, container, false)

        btnCreateLfg = view.findViewById(R.id.btn_lfg_create)
        minPlayerInput = view.findViewById(R.id.input_lfg_min_player)

        //retrofit
//        val repo = Repo()
//        val viewModelFactory = ViewModelFactory(repo)
//        viewModel = ViewModelProvider(this, viewModelFactory).get(ViewModelSportList::class.java)
//        viewModel.getPost()
//        viewModel.sportList.observe(viewLifecycleOwner, Observer { response ->
//            if (response.isSuccessful){
//                response.body()?.let { sportAdapter.setData(it) }
//            }
//            else{
//                Log.d("print", "lfg response failed")
//            }
//        })

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        addFragmentWithTag(this, "lfg_create_new")

        domicileSpinner = view.findViewById(R.id.spinner_lfg_domicile)

        val domicile_list = resources.getStringArray(R.array.domicile_list)
        if (domicileSpinner != null) {
            val adapter = ArrayAdapter(
                requireContext(),
                android.R.layout.simple_spinner_item, domicile_list
            )
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            domicileSpinner.adapter = adapter
        }

        sportSpinner = view.findViewById(R.id.spinner_lfg_sport_type)
//        RetrofitClient.instance.getFavSport().enqueue(object : Callback<ArrayList<FavSportData>> {
//            override fun onResponse(
//                call: Call<ArrayList<FavSportData>>,
//                response: Response<ArrayList<FavSportData>>
//            ) {
//                response.body()?.let { list.addAll(it) }
//                val adapter = SportListAdapter(requireContext(), 3, list)
//                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
//                sportSpinner.adapter = adapter
//
//            }
//
//            override fun onFailure(call: Call<ArrayList<FavSportData>>, t: Throwable) {
//                Log.d("print", "LFG on failure called")
//            }
//
//        })

        sportSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {
                // When a spinner item is selected, change the text view's text
                val a = parent.getItemAtPosition(position).toString()
                if(a == "Badminton"){
                    minPlayerInput.hint = "Enter min. player (max 8)"
                }
                else{
                    minPlayerInput.hint = "Enter min. player (max 10)"
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                // Optional: If no item is selected, you can have some default text here
                minPlayerInput.hint = "Please select a sport"
            }
        }

        val alertDialog = getActivity()?.let {

            AlertDialog.Builder(it)
                .setTitle("Confirm Create LFG")
                .setMessage("Are you sure you want to create this LFG")
                .setPositiveButton("Yes") { _, _ ->
                    val frag = LfgDetails()
                    val tran = fragmentManager?.beginTransaction()
                    tran?.addToBackStack("lfg_create")
                    tran?.replace(R.id.fragment_cont, frag)?.commit()
                }
                .setNegativeButton("Cancel") { _, _ -> }
                .create()
        }

        btnCreateLfg.setOnClickListener {
            if (alertDialog != null) {
                showAlertDialog(alertDialog)
            }
        }
    }

    private fun showAlertDialog(alertDialog: AlertDialog) {
        if (!alertDialog.isShowing) {
            alertDialog.show()
        }
    }

    fun addFragmentWithTag(fragment: Fragment, tag: String) {
        activity?.supportFragmentManager?.beginTransaction()
            ?.replace(R.id.fragment_cont, fragment, tag)
            ?.commit()
    }

}