package com.example.fitme_up.user.dataset

data class SettingsTopUpData(val topupId: String, val topupDate: String, val topupAmount: Int)
