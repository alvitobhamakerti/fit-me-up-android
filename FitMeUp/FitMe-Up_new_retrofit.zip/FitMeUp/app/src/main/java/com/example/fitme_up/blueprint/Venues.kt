package com.example.fitme_up.blueprint

data class Venues(
    val id: Int,
    val venue_name: String,
    val venue_address: String,
    val venue_time_open: String,
    val venue_time_close: String,
    val venue_description: String
)
