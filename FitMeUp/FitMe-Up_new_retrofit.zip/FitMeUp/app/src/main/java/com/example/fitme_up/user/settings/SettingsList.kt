package com.example.fitme_up.user.settings

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.fitme_up.OnItemClickListener
import com.example.fitme_up.R
import com.example.fitme_up.Repo
import com.example.fitme_up.blueprint.Domicile
import com.example.fitme_up.blueprint.MainData
import com.example.fitme_up.user.adapter.lfgAdapter.LfgTab1Adapter
import com.example.fitme_up.user.adapter.settingsAdapter.SettingsAdapter
import com.example.fitme_up.viewmodel.ViewModelFactory
import com.example.fitme_up.viewmodel.ViewModelSportList
import com.google.gson.Gson

class SettingsList : Fragment(), OnItemClickListener {

    private lateinit var viewAdapter: RecyclerView.Adapter<*>
    private lateinit var viewManager: RecyclerView.LayoutManager
    private lateinit var recyclerView: RecyclerView


    //retrofit
    private lateinit var viewModel: ViewModelSportList
//    val sportAdapter by lazy { SettingsAdapter() }

    private var domicileList = ArrayList<MainData>()

//    private val list = ArrayList<FavSportData>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_settings_list, container, false)

        recyclerView = view.findViewById(R.id.recycler_settings)

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewManager = LinearLayoutManager(context)
        recyclerView.layoutManager = viewManager

        domicileList = ArrayList()

        var w = emptyList<String>()

        val repo = Repo()
        val viewModelFactory = ViewModelFactory(repo)
        viewModel = ViewModelProvider(this, viewModelFactory).get(ViewModelSportList::class.java)
        viewModel.getPost2()
        viewModel.domicileList.observe(viewLifecycleOwner, Observer { response ->
            if (response.isSuccessful){
                response.body()?.let { domicileList.addAll(listOf(it)) }
//                Log.d("print", response.body()?.data?.get(0)?.domicile_name.toString())

                for (i in 0..<response.body()!!.data.size){
//                    Log.d("print", response.body()?.data?.get(i)?.domicile_name.toString())
                    w = listOf(response.body()?.data?.get(i)?.domicile_name.toString())
                    Log.d("print", w.toString())    //for loop masih agak agak
                }

            Log.d("print", response.message()) //response -> ok


            }
            else{
                Log.d("print", "lfg response failed")
            }
        })

        viewAdapter = SettingsAdapter(w, this) //cek constructor adapter -> SettingsAdapter(...)
        recyclerView.adapter = viewAdapter

    }

    override fun onItemClick(position: Int) {
        val fragment: Fragment = when (position) {
            0 -> SettingsEditProfile()
            1 -> SettingsTopUpBalance()
            2 -> SettingsWithdrawBalance()
            else -> SettingsTransactionHistory()
        }

        activity?.supportFragmentManager?.beginTransaction()
            ?.replace(R.id.fragment_cont, fragment)
            ?.addToBackStack(null)
            ?.commit()
    }

}