package com.example.fitme_up.venueowner

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.example.fitme_up.R
import com.example.fitme_up.ViewModelFragmentTag

class VenueOwnerBookDetails : Fragment() {

    private lateinit var bottomBtn: ConstraintLayout
    private lateinit var sharedViewModel: ViewModelFragmentTag

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_venue_owner_book_details, container, false)

        bottomBtn = view.findViewById(R.id.layout_payment)
        sharedViewModel = ViewModelProvider(requireActivity()).get(ViewModelFragmentTag::class.java)

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        sharedViewModel.selectedState.observe(viewLifecycleOwner, Observer { selected ->
            if (selected != null) {
                //ini buat get sport di page sebelumnya
                when (selected) {
                    "on_progress" -> {
                        Log.d("print", "$selected")
                        bottomBtn.visibility = View.GONE
                    }
                }
            }
            else{
                bottomBtn.visibility = View.VISIBLE
            }
        })

    }
}