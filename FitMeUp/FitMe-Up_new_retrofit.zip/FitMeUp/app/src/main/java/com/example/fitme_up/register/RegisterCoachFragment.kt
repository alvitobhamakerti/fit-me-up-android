package com.example.fitme_up.register

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import androidx.fragment.app.Fragment
import com.example.fitme_up.R

class RegisterCoachFragment : Fragment() {


    var nameEditText: EditText? = null
    var emailEditText: EditText? = null
    var passwordEditText: EditText? = null
    var confirmPasswordEditText: EditText? = null
    var dobEditText: EditText? = null
    lateinit var registerButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_register_coach, container, false)

        nameEditText = view.findViewById(R.id.input_register_coach_name)
        emailEditText = view.findViewById(R.id.input_register_coach_email)
        passwordEditText = view.findViewById(R.id.input_register_coach_password)
        confirmPasswordEditText = view.findViewById(R.id.input_register_coach_confirm_password)
        dobEditText = view.findViewById(R.id.input_register_coach_dob)
        registerButton = view.findViewById(R.id.registerButtonCoach)

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        registerButton.setOnClickListener {
            val userFrag = RegisterCoachFragment2()
            val tran = fragmentManager?.beginTransaction()
            tran?.replace(R.id.frame_register_cont, userFrag)?.commit()
            tran?.addToBackStack(null)
        }

    }

}