package com.example.fitme_up

import com.example.fitme_up.blueprint.DataPost
import com.example.fitme_up.blueprint.Domicile
import com.example.fitme_up.blueprint.MainData
import retrofit2.Response
import retrofit2.http.GET

interface Api {

    @GET("posts")
//    @GET("posts")
//    suspend fun getFavSport(@Query("sport_name") sport_name: String): Call<ArrayList<FavSportData>>
//    fun getFavSport(): Call<ArrayList<FavSportData>>
    suspend fun getFavSport(): Response<List<DataPost>>

//    @GET("domicile")
//    suspend fun getDomicile(): Response<Domicile>

    @GET("domicile")
    suspend fun getDomicile(): Response<MainData>//udah bener, kl mau ganti ganti ke Domicile -> ke viewmodel jg


}

