package com.example.fitme_up.user.dataset

data class LfgPlayerData(val full_name: String, val player_status: String)
