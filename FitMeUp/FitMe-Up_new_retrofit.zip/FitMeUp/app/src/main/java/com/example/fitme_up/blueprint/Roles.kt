package com.example.fitme_up.blueprint

data class Roles(
    val id: Int,
    val role_name: String
)
