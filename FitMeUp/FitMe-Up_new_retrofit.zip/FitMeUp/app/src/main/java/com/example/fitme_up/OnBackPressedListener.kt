package com.example.fitme_up

interface OnBackPressedListener {
    fun onBackPressed()
}