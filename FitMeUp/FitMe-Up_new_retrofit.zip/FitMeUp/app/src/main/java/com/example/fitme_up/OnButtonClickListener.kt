package com.example.fitme_up

interface OnButtonClickListener {
    fun onButtonClick()
}