package com.example.fitme_up.venueowner.adapter

class VenueOwnerCupListAdapter {
}