package com.example.fitme_up.user.adapter.settingsAdapter

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.RecyclerView
import com.example.fitme_up.R
import com.example.fitme_up.blueprint.Domicile
import com.example.fitme_up.blueprint.FavSportData
import com.example.fitme_up.blueprint.MainData
import com.example.fitme_up.user.dataset.LfgData

class SettingsAdapter(private val myDataset: List<String>, private val parentFragment: Fragment) : RecyclerView.Adapter<SettingsAdapter.ViewHolder>() {

//    private var items = emptyList<DataPost>()
    private var items = emptyList<MainData>()// kl mau ganti ke Domicile -> dari API

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val settingsName: TextView = view.findViewById(R.id.text_settings_name)
        val settingsicon: ImageView = view.findViewById(R.id.icon_settings)
        val layout: CardView = view.findViewById(R.id.card_settings_list)

        fun bind(item: FavSportData) {
            with(itemView){
//                val a = "id: " + item.id + "sport name: " + item.sport_name
//                settingsName.text = item.sport_name + item.id.toString()
            }

        }

//        init {
//            itemView.setOnClickListener {
//                onItemClickListener.onItemClick(adapterPosition)
//            }
//        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.recycler_settings, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
//        holder.bind(settingsList[position])
//        val item = items[position]
        holder.settingsName.text = items.get(position).data.get(position).domicile_name

    }

    override fun getItemCount() = items.size

    fun setData(newList: List<MainData>){
        items = newList
        notifyDataSetChanged()
        Log.d("print", "get post" + newList.toString())
    }

//    fun setData2(newList: List<Domicile>){
////        items = newList
//        notifyDataSetChanged()
//
//    }


//    override fun onItemClick(position: Int) {
//        TODO("Not yet implemented")
//    }

}