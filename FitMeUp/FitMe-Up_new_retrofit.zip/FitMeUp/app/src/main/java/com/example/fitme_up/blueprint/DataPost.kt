package com.example.fitme_up.blueprint

data class DataPost(
    val userId: Int,
    val id: Int,
    val title: String,
    val body: String
)
