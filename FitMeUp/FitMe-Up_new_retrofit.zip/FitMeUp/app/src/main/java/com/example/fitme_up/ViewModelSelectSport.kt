package com.example.fitme_up

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class ViewModelSelectSport : ViewModel() {

    private val _selectedState = MutableLiveData<String?>()
    val selectedState: MutableLiveData<String?>
        get() = _selectedState

    fun updateSelectedState(selected: String?) {
        _selectedState.value = selected
    }
}