package com.example.fitme_up.blueprint

data class MainData (val message: String, val data: List<Domicile>)