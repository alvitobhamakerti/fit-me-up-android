package com.example.fitme_up

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.fitme_up.user.adapter.HomeAdapter
import com.example.fitme_up.user.adapter.VenueAdapter
import com.example.fitme_up.user.dataset.ActivityData
import com.example.fitme_up.user.dataset.VenueData

class HomeUserFragment : Fragment() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var recyclerView2: RecyclerView
    private lateinit var viewAdapter: RecyclerView.Adapter<*>
    private lateinit var viewAdapter2: RecyclerView.Adapter<*>
    private lateinit var viewManager: RecyclerView.LayoutManager
    private lateinit var viewManager2: RecyclerView.LayoutManager

    companion object {
        fun newInstance() = HomeUserFragment()
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_home, container, false)

        return view
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        recyclerView = requireView().findViewById(R.id.activityRecycleList)
        recyclerView2 = requireView().findViewById(R.id.venueRecycleListTab1)
        viewManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
        viewManager2 = LinearLayoutManager(context)
        recyclerView.layoutManager = viewManager
        recyclerView2.layoutManager = viewManager2

        val dataList = listOf(
            ActivityData("Image 1", "Activity Name 1", "Domicile 1"),
            ActivityData("Image 2", "Activity Name 2", "Domicile 2"),
            ActivityData("Image 3", "Activity Name 3", "Domicile 3")
        )

        val dataList2 = listOf(
            VenueData("Venue 1", "Badminton", "Domicile 1", 15000),
            VenueData("Venue 2", "Badminton", "Domicile 2", 15000),
            VenueData("Venue 3", "Futsal", "Domicile 3", 15000)
        )
        viewAdapter = HomeAdapter(dataList)
        viewAdapter2 = VenueAdapter(dataList2)

        recyclerView.adapter = viewAdapter
        recyclerView2.adapter = viewAdapter2
    }

}