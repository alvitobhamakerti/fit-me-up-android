package com.example.fitme_up.user.dataset

data class VenueData(val venue_name: String, val sports_name: String, val domicile: String, val venue_price: Int)
