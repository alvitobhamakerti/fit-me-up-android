package com.example.fitme_up.user.dataset

data class SettingsData(val settings_icon: Int, val settings_title: String)