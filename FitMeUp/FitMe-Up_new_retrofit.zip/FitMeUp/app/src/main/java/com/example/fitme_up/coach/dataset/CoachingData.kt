package com.example.fitme_up.coach.dataset

data class CoachingData(val venueName: String, val venueDomicile: String, val venueSport: String, val bookDate: String, val bookDuration: Int)
