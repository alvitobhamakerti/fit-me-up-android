package com.example.fitme_up.blueprint

data class Users(
    val id: Int,
    val email: String,
    val password: String,
    val role_id: Int
)