package com.example.fitme_up.user.booking

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Spinner
import android.widget.Toast
import com.example.fitme_up.R

class BookingVenueOrder : Fragment() {

    private lateinit var venueOrderBtn: Button
    private lateinit var venueDateSpin: Spinner

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_booking_venue_order, container, false)

        venueOrderBtn = view.findViewById(R.id.btn_confirm_venue)
        venueDateSpin = view.findViewById(R.id.spin_venue_book_date)

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)



        val fragmentManager = activity?.supportFragmentManager
        if (fragmentManager != null) {
            val backStackCount = fragmentManager.backStackEntryCount
            if (backStackCount > 0) {

                val fm = fragmentManager.findFragmentByTag("lfg_venue_details")

                if (fm != null) {
                    addFragmentWithTag(this, "lfg_venue_order")
                    Log.d("print", "from lfg venue details")
                    venueOrderBtn.text = "Book Venue for LFG"

                    venueDateSpin.visibility = View.GONE
                    //tambah logic data kalo dari lfg (masukin ke lfg DB)
                }
            }
        }

        venueOrderBtn.setOnClickListener() {
            val frag = BookingVenueConfirm()
            val tran = fragmentManager?.beginTransaction()
            tran?.addToBackStack(null)
            tran?.replace(R.id.fragment_cont, frag)?.commit()
        }
    }

    fun addFragmentWithTag(fragment: Fragment, tag: String) {
        activity?.supportFragmentManager?.beginTransaction()
            ?.replace(R.id.fragment_cont, fragment, tag)
            ?.commit()
    }
}