package com.example.fitme_up.register

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ImageButton
import android.widget.Spinner
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.fitme_up.R
import com.example.fitme_up.ViewModelSelectSport

class RegisterVenueOwnerFragment2 : Fragment() {

    private lateinit var btnBadminton: ImageButton
    private lateinit var btnFutsal: ImageButton
    private lateinit var btnSelectSport: Button
    private lateinit var badmintonText: TextView
    private lateinit var futsalText: TextView
    private lateinit var domicileSpinner: Spinner
    private lateinit var sharedViewModel: ViewModelSelectSport

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_register_venue_owner2, container, false)

        btnBadminton = view.findViewById(R.id.btn_select_badminton)
        btnFutsal = view.findViewById(R.id.btn_select_futsal)
        btnSelectSport = view.findViewById(R.id.btn_register_venue_owner_select_sport)
        futsalText = view.findViewById(R.id.text_select_futsal)
        badmintonText = view.findViewById(R.id.text_select_badminton)
        domicileSpinner = view.findViewById(R.id.spinner_venue_owner_register_domicile)

        sharedViewModel = ViewModelProvider(requireActivity()).get(ViewModelSelectSport::class.java)

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        sharedViewModel.updateSelectedState(null)

        btnBadminton.setBackgroundResource(R.drawable.button_toggle_selector)
        btnFutsal.setBackgroundResource(R.drawable.button_toggle_selector)

        context?.let { it1 -> badmintonText.setTextColor(it1.getColor(R.color.birutua)) }
        context?.let { it1 -> futsalText.setTextColor(it1.getColor(R.color.birutua)) }

        //ini buat select sport
        btnBadminton.setOnClickListener {
            btnBadminton.isSelected = !btnBadminton.isSelected
            if (btnBadminton.isSelected) {
                btnFutsal.isSelected = false
                context?.let { it1 -> badmintonText.setTextColor(it1.getColor(R.color.white)) }
                context?.let { it1 -> futsalText.setTextColor(it1.getColor(R.color.birutua)) }
                sharedViewModel.updateSelectedState("Badminton")
            } else {
                context?.let { it1 -> badmintonText.setTextColor(it1.getColor(R.color.birutua)) }
                sharedViewModel.updateSelectedState(null)
            }
        }

        btnFutsal.setOnClickListener() {
            btnFutsal.isSelected = !btnFutsal.isSelected
            if (btnFutsal.isSelected) {
                btnBadminton.isSelected = false
                context?.let { it1 -> futsalText.setTextColor(it1.getColor(R.color.white)) }
                context?.let { it1 -> badmintonText.setTextColor(it1.getColor(R.color.birutua)) }
                sharedViewModel.updateSelectedState("Futsal")

            } else {
                context?.let { it1 -> futsalText.setTextColor(it1.getColor(R.color.birutua)) }
                sharedViewModel.updateSelectedState(null)
            }
        }

        val domicile_list = resources.getStringArray(R.array.domicile_list)
        if (domicileSpinner != null) {
            val adapter = ArrayAdapter(
                requireContext(),
                android.R.layout.simple_spinner_item, domicile_list
            )
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            domicileSpinner.adapter = adapter
        }

        btnSelectSport.setOnClickListener() {
            if (btnBadminton.isSelected || btnFutsal.isSelected) {
                val frag = RegisterVenueOwnerFragment3()
                val tran = fragmentManager?.beginTransaction()
                tran?.replace(R.id.frame_register_cont, frag)?.commit()
                tran?.addToBackStack(null)
            }

        }
    }

}