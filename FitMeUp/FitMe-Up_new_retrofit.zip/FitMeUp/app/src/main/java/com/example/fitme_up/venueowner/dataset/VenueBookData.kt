package com.example.fitme_up.venueowner.dataset

data class VenueBookData(val venueSport: String, val orderID: String, val bookStatus: String)
