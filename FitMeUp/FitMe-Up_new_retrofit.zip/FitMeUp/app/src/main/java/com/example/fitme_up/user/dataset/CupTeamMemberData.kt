package com.example.fitme_up.user.dataset

data class CupTeamMemberData(val full_name: String, val player_status: String)
